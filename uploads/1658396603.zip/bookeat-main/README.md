
![Logo](https://i.ibb.co/QnkpCyK/Git-banner.png)![Twitter Follow](https://img.shields.io/twitter/follow/Nya3ali?color=red&style=for-the-badge) 


# Book`EAT

A simple Online restaurant Table Booking system in PHP w/MySQL Database. 

Customer side and Admin panel side are both included in this system.

Restaurants can register on this Booking system to propose tables, wich customers after regitering can search a restaurant by area, type of food, see the menu that it offers, and choose to book a table. 

There is a registration and login system for customers, and of course each restaurants will have access to their own Admin panel to manage/modify tables availability, bookings, meal etc...

After the booking has been accepted by the restaurant, the customer will get a conformation E-Mail.

The Customers and Restaurants can also update/manage all their informations.


## Demo : 

https://youtu.be/EabhAZR9k0I


## Features

- PHP Mailer
- Sweet Alert
- Font Awesome
- Bootstrap
- Jquery
- SQL Database


## 🚀 About Me
I'm a full stack developer...
And an Atckin Solej


![Logo](https://i.ibb.co/TLtzz6H/3.png)

