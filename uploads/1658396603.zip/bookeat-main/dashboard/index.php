<!-- index.php -->
<?php 
header("location: accueil.php");
?>