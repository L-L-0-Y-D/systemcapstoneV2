<style>
html body{
	position: relative;
	margin: 0;
    width:100%;
    height:100px;
    background:white;
}
</style>
<!-- Sweet Alert -->
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>