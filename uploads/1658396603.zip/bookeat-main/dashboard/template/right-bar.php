<aside id="sidebar-right" class="sidebar-right">
	<div class="nano">
		<div class="nano-content">
			<a href="#" class="mobile-close visible-xs">
				Collapse <i class="fa fa-chevron-right"></i>
			</a>

			<div class="sidebar-right-wrapper">
				<div class="card bg-light mb-3 text-center" style="max-width: 100%;">
					<h5>A question, a suggestion?</h5>
					<br>
					<div class="card-header">Contact The Admin APP</div>
					<br>
					<div class="card-body">
						<h6 class="card-title">Contact Us : </h6>
						<p class="card-text">info@mail.fr</p>
						<h6 class="card-title">Call Us : </h6>
						<p class="card-text">04-67-00-02-01</p>
					</div>
					<br>
					<div class="card-footer text-muted">
						<a href="#"><i class="fab fa-facebook-square fa-2x"></i></a>
						<a href="#"><i class="fab fa-instagram-square fa-2x"></i></a>
						<a href="#"><i class="fab fa-twitter-square fa-2x"></i></a>
					</div>
				</div>

			</div>
		</div>
	</div>
</aside>